package com.example.opsc_p2_ameer_miller_st10067171

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.github.mikephil.charting.charts.PieChart
import com.github.mikephil.charting.components.Description
import com.github.mikephil.charting.data.PieData
import com.github.mikephil.charting.data.PieDataSet
import com.github.mikephil.charting.data.PieEntry
import com.github.mikephil.charting.utils.ColorTemplate

class GraphActivity : AppCompatActivity() {

    private lateinit var pieChart: PieChart
    private lateinit var noDataText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_graph)

        pieChart = findViewById(R.id.pieChart)
        noDataText = findViewById(R.id.noDataText)

        // Example placeholder data
        val dummyExpenses = listOf(
            Pair("Food", 200f),
            Pair("Transport", 150f),
            Pair("Utilities", 100f)
        )

        if (dummyExpenses.isEmpty()) {
            pieChart.visibility = PieChart.INVISIBLE
            noDataText.text = "No expense data available."
            noDataText.visibility = TextView.VISIBLE
            return
        }

        val entries = dummyExpenses.map { PieEntry(it.second, it.first) }

        val dataSet = PieDataSet(entries, "Example Expenses")
        dataSet.setColors(*ColorTemplate.MATERIAL_COLORS)

        val data = PieData(dataSet)
        pieChart.data = data
        pieChart.description = Description().apply { text = "Example Expense Distribution" }
        pieChart.animateY(1000)
        pieChart.invalidate()
    }
}
