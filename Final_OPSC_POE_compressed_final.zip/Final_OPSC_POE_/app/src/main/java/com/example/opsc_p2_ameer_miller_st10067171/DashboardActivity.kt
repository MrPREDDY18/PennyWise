package com.example.opsc_p2_ameer_miller_st10067171

import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import java.io.File
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.*

class DashboardActivity : AppCompatActivity() {

    // Profile Views
    private lateinit var editTextName: EditText
    private lateinit var editTextBio: EditText
    private lateinit var buttonSaveProfile: Button
    private lateinit var textViewProfile: TextView
    private lateinit var textViewActivityLog: TextView

    // Expense Views
    private lateinit var editTextDate: EditText
    private lateinit var editTextTime: EditText
    private lateinit var editTextDescription: EditText
    private lateinit var spinnerCategory: Spinner
    private lateinit var buttonAddCategory: Button
    private lateinit var buttonAddExpense: Button
    private lateinit var editTextMinGoal: EditText
    private lateinit var editTextMaxGoal: EditText
    private lateinit var buttonSetGoal: Button
    private lateinit var buttonViewTotal: Button
    private lateinit var textViewTotalDisplay: TextView
    private lateinit var listViewExpenses: ListView
    private lateinit var buttonViewGraph: Button
    private lateinit var buttonTakePhoto: Button
    private lateinit var buttonGamification: Button
    private lateinit var openProgress: Button

    // Categories display
    private lateinit var textViewCategories: TextView

    // Data
    private var totalAmount = 0.0
    private val expenses = mutableListOf<String>()
    private val categories = mutableListOf("Food", "Transport", "Entertainment")

    // Camera
    private val REQUEST_IMAGE_CAPTURE = 1
    private var currentPhotoPath: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dashboard)

        // Create notification channel (Android 8.0+)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                "dashboard_channel",
                "Dashboard Notifications",
                NotificationManager.IMPORTANCE_DEFAULT
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }

        // Initialize views
        editTextName = findViewById(R.id.editTextName)
        editTextBio = findViewById(R.id.editTextBio)
        buttonSaveProfile = findViewById(R.id.buttonSaveProfile)
        textViewProfile = findViewById(R.id.textViewProfile)
        textViewActivityLog = findViewById(R.id.textViewActivityLog)

        editTextDate = findViewById(R.id.editTextDate)
        editTextTime = findViewById(R.id.editTextTime)
        editTextDescription = findViewById(R.id.editTextDescription)
        spinnerCategory = findViewById(R.id.spinnerCategory)
        buttonAddCategory = findViewById(R.id.buttonAddCategory)
        buttonAddExpense = findViewById(R.id.buttonAddExpense)
        editTextMinGoal = findViewById(R.id.editTextMinGoal)
        editTextMaxGoal = findViewById(R.id.editTextMaxGoal)
        buttonSetGoal = findViewById(R.id.buttonSetGoal)
        buttonViewTotal = findViewById(R.id.buttonViewTotal)
        textViewTotalDisplay = findViewById(R.id.textViewTotalDisplay)
        listViewExpenses = findViewById(R.id.listViewExpenses)
        buttonViewGraph = findViewById(R.id.buttonViewGraph)
        buttonTakePhoto = findViewById(R.id.buttonTakePhoto)
        buttonGamification = findViewById(R.id.buttonGamification)
        openProgress = findViewById(R.id.openProgress)
        textViewCategories = findViewById(R.id.textViewCategories)

        textViewCategories.text = "Categories: ${categories.joinToString(", ")}"

        val spinnerAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, categories)
        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinnerCategory.adapter = spinnerAdapter

        // Save Profile
        buttonSaveProfile.setOnClickListener {
            val name = editTextName.text.toString()
            val bio = editTextBio.text.toString()
            textViewProfile.text = "Name: $name\nBio: $bio"
            appendToActivityLog("Saved profile for $name")
            showNotification("Profile Saved", "Your profile information has been successfully saved.")
        }

        // Add Category
        buttonAddCategory.setOnClickListener {
            val category = editTextDescription.text.toString().trim()
            if (category.isNotEmpty()) {
                if (!categories.contains(category)) {
                    categories.add(category)
                    spinnerAdapter.notifyDataSetChanged()
                    appendToActivityLog("Added category: $category")
                    textViewCategories.text = "Categories: ${categories.joinToString(", ")}"
                    showToast("Category \"$category\" added.")
                    showNotification("Category Added", "New category \"$category\" has been added.")
                } else {
                    showToast("Category \"$category\" already exists.")
                }
            } else {
                showToast("Please enter a category name.")
            }
        }

        // Add Expense
        buttonAddExpense.setOnClickListener {
            val date = editTextDate.text.toString()
            val amountText = editTextTime.text.toString()
            val desc = editTextDescription.text.toString()
            val category = spinnerCategory.selectedItem.toString()

            if (amountText.isNotEmpty()) {
                val amount = amountText.toDouble()
                totalAmount += amount
                val expense = "$date | $category: R$amount - $desc"
                expenses.add(expense)
                listViewExpenses.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, expenses)
                appendToActivityLog("Added expense: $expense")
                showNotification("Expense Added", "Expense of R$amount added to category: $category.")
            } else {
                showToast("Please enter an amount.")
            }
        }

        buttonViewTotal.setOnClickListener {
            textViewTotalDisplay.text = "Total: R%.2f".format(totalAmount)
        }

        buttonSetGoal.setOnClickListener {
            val min = editTextMinGoal.text.toString()
            val max = editTextMaxGoal.text.toString()
            appendToActivityLog("Set goal: Min = R$min, Max = R$max")
            showToast("Goal set")
            showNotification("Goal Set", "Your goal has been set: Min R$min, Max R$max")
        }

        // Navigation and feature buttons
        buttonViewGraph.setOnClickListener { onViewGraphClicked() }
        buttonTakePhoto.setOnClickListener { onTakePhotoClicked() }
        buttonGamification.setOnClickListener { onGamificationClicked() }
        openProgress.setOnClickListener { onOpenProgressClicked() }
    }

    // Navigation methods
    private fun onViewGraphClicked() {
        showToast("Opening Graph")
        val intent = Intent(this, GraphActivity::class.java)
        startActivity(intent)
    }

    private fun onGamificationClicked() {
        showToast("Opening Gamification")
        val intent = Intent(this, GamificationActivity::class.java)
        startActivity(intent)
    }

    private fun onOpenProgressClicked() {
        showToast("Opening Progress")
        val intent = Intent(this, ProgressActivity::class.java)
        startActivity(intent)
    }

    // Camera methods
    private fun onTakePhotoClicked() {
        showToast("Launching Camera")
        dispatchTakePictureIntent()
    }

    private fun dispatchTakePictureIntent() {
        val takePictureIntent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        if (takePictureIntent.resolveActivity(packageManager) != null) {
            val photoFile: File? = try {
                createImageFile()
            } catch (ex: IOException) {
                showToast("Error creating photo file")
                null
            }
            photoFile?.also {
                val photoURI: Uri = FileProvider.getUriForFile(
                    this,
                    "${applicationContext.packageName}.fileprovider",
                    it
                )
                takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI)
                startActivityForResult(takePictureIntent, REQUEST_IMAGE_CAPTURE)
            }
        } else {
            showToast("No camera app found")
        }
    }

    @Throws(IOException::class)
    private fun createImageFile(): File {
        val timeStamp: String = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val storageDir: File = getExternalFilesDir(Environment.DIRECTORY_PICTURES)!!
        return File.createTempFile(
            "JPEG_${timeStamp}_",
            ".jpg",
            storageDir
        ).apply {
            currentPhotoPath = absolutePath
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_IMAGE_CAPTURE && resultCode == Activity.RESULT_OK) {
            showToast("Photo saved at $currentPhotoPath")
            // You can add code here to display or upload the photo if needed
        } else {
            showToast("Photo capture cancelled")
        }
    }

    // Utility functions
    private fun appendToActivityLog(entry: String) {
        val current = textViewActivityLog.text.toString()
        textViewActivityLog.text = if (current.isEmpty()) entry else "$current\n$entry"
    }

    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    private fun showNotification(title: String, message: String) {
        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, "dashboard_channel")
        } else {
            Notification.Builder(this)
        }
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title)
            .setContentText(message)
            .setAutoCancel(true)

        val manager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        manager.notify(System.currentTimeMillis().toInt(), builder.build())
    }
}
