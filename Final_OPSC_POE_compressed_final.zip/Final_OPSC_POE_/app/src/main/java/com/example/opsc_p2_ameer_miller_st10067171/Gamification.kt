package com.example.opsc_p2_ameer_miller_st10067171

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.widget.TextView

class GamificationActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_gamification)

        val gamificationText = findViewById<TextView>(R.id.gamificationText)
        gamificationText.text = "You've unlocked a new badge! 🎉"
    }
}
