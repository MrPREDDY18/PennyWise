package com.example.opsc_p2_ameer_miller_st10067171

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class BudgetActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_budget)

        val recyclerView = findViewById<RecyclerView>(R.id.recyclerViewExpenses)
        val totalExpenseTextView = findViewById<TextView>(R.id.textViewTotalExpense)
        val graphButton = findViewById<Button>(R.id.viewGraphButton)

        // Setup RecyclerView with Adapter
        recyclerView.layoutManager = LinearLayoutManager(this)


        graphButton.setOnClickListener {
            startActivity(Intent(this, GraphActivity::class.java))
        }
    }
}
