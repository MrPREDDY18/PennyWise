package com.example.opsc_p2_ameer_miller_st10067171

import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class SignupActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_signup)

        val nameInput = findViewById<EditText>(R.id.nameInput)
        val surnameInput = findViewById<EditText>(R.id.surnameInput)
        val usernameInput = findViewById<EditText>(R.id.signupUsername)
        val passwordInput = findViewById<EditText>(R.id.signupPassword)
        val signUpBtn = findViewById<Button>(R.id.submitSignUp)
        val loginRedirectBtn = findViewById<Button>(R.id.loginRedirectButton) // New button

        // ✅ Handle sign-up submission
        signUpBtn.setOnClickListener {
            val name = nameInput.text.toString().trim()
            val surname = surnameInput.text.toString().trim()
            val username = usernameInput.text.toString().trim()
            val password = passwordInput.text.toString().trim()

            if (name.isNotEmpty() && surname.isNotEmpty() && username.isNotEmpty() && password.isNotEmpty()) {
                Toast.makeText(this, "Registered $name $surname!", Toast.LENGTH_SHORT).show()

                // ✅ Redirect to login screen
                val intent = Intent(this, LoginActivity::class.java)
                startActivity(intent)
                finish()
            } else {
                Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show()
            }
        }

        // ✅ Handle direct login button
        loginRedirectBtn.setOnClickListener {
            val intent = Intent(this, LoginActivity::class.java)
            startActivity(intent)
            finish()
        }
    }
}
