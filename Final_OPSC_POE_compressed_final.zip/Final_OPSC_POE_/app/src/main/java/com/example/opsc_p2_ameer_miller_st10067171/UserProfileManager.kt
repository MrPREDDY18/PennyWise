package com.example.profile

import android.content.Context
import android.content.SharedPreferences

class UserProfileManager(context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences("user_profile", Context.MODE_PRIVATE)

    fun saveProfile(name: String, bio: String) {
        prefs.edit().putString("name", name).putString("bio", bio).apply()
    }

    fun getName(): String? = prefs.getString("name", null)
    fun getBio(): String? = prefs.getString("bio", null)
}
