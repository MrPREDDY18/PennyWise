package com.example.opsc_p2_ameer_miller_st10067171

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class GoalActivity : AppCompatActivity() {

    private lateinit var goalNameInput: EditText
    private lateinit var minGoalInput: EditText
    private lateinit var maxGoalInput: EditText
    private lateinit var saveGoalButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_goal)

        goalNameInput = findViewById(R.id.editTextGoalName)
        minGoalInput = findViewById(R.id.editTextMinGoalAmount)
        maxGoalInput = findViewById(R.id.editTextMaxGoalAmount)
        saveGoalButton = findViewById(R.id.buttonSaveGoal)

        saveGoalButton.setOnClickListener {
            val goalName = goalNameInput.text.toString().trim()
            val min = minGoalInput.text.toString().toFloatOrNull()
            val max = maxGoalInput.text.toString().toFloatOrNull()

            if (goalName.isEmpty() || min == null || max == null) {
                Toast.makeText(this, "Please fill all fields with valid values", Toast.LENGTH_SHORT).show()
            } else {
                // Here you can store the goal in shared preferences, a DB, or a global list
                Toast.makeText(this, "Goal \"$goalName\" set (Min: $min, Max: $max)", Toast.LENGTH_LONG).show()

                goalNameInput.text.clear()
                minGoalInput.text.clear()
                maxGoalInput.text.clear()
            }
        }
    }
}
