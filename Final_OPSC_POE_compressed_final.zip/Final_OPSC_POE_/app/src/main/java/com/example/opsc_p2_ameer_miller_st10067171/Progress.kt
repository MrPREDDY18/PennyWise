package com.example.opsc_p2_ameer_miller_st10067171

import android.os.Bundle
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class ProgressActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_progress)

        val progressBar = findViewById<ProgressBar>(R.id.progressBar)
        val progressText = findViewById<TextView>(R.id.progressText)

        // Define your goal
        val goal = 1000.0

        // Example hardcoded total expenses
        val totalExpenses = 450.0  // <- Replace with actual logic later

        val progress = ((totalExpenses / goal) * 100).toInt().coerceAtMost(100)

        progressBar.progress = progress
        progressText.text = "$progress% of your goal achieved"
    }
}
