package com.example.opsc_p2_ameer_miller_st10067171

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.profile.UserProfileManager
import com.example.activitylog.ActivityLogger

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Handle login button click
        val buttonGoToLogin: Button = findViewById(R.id.buttonGoToLogin)
        buttonGoToLogin.setOnClickListener {
            startActivity(Intent(this, LoginActivity::class.java))
        }

        // Save and retrieve profile
        val profileManager = UserProfileManager(this)
        profileManager.saveProfile("Liam", "App Developer")

        // Log activity
        val activityLogger = ActivityLogger(this)
        activityLogger.logActivity("Visited MainActivity")

        // Fetch saved profile and log data
        val name = profileManager.getName()
        val bio = profileManager.getBio()
        val log = activityLogger.getLog()

        // Optional: Log output to Logcat
        Log.d("User", "Name: $name, Bio: $bio")
        Log.d("ActivityLog", log)
    }
}
