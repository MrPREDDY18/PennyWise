package com.example.activitylog

import android.content.Context
import android.content.SharedPreferences

class ActivityLogger(context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences("activity_log", Context.MODE_PRIVATE)

    fun logActivity(activity: String) {
        val existingLog = prefs.getString("log", "") ?: ""
        val updatedLog = "$existingLog\n$activity"
        prefs.edit().putString("log", updatedLog).apply()
    }

    fun getLog(): String = prefs.getString("log", "") ?: ""
}
