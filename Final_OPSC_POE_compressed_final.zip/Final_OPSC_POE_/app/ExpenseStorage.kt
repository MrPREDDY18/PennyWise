class ExpenseStorage {
    object ExpenseStorage {
        val expenseList = mutableListOf<Expense>()
    }