
# Budget Tracker App – OPSC Part 3

## 👤 Developer
**Ameer Miller – ST10067171**

---

## 📱 App Purpose
The Budget Tracker helps users manage their expenses, track budgets, and receive visual and gamified feedback on their financial health.

---

## ✅ Key Features
- **Login/Signup authentication**
- **Expense tracking** by category
- **Budget setting** with alert system
- **Gamification:** points, reward levels
- **Graphical summary** of spending
- **Custom Features:**
  - Category Expense Summary
  - Budget Alert Notifications

---

## 📊 Design Considerations
- Consistent use of color, spacing, and fonts
- Clean UI with intuitive navigation
- Responsive layout for physical devices

---

## 🧪 Usage of GitHub & Actions
- Full project hosted on GitHub (link here)
- Commit logs used for tracking
- Includes comments and logging in code

---

## 🎥 Video Demo
Watch here: [Insert YouTube or Drive link]

---

## 📦 Build Information
- Final APK: Located in `/app/release/app-release.apk`
- Compatible with Android 8+

---

## 📷 Screenshots
(Include screenshots here)

---

## 🧩 Research & Docs
See design and planning docs submitted with Part 1.
