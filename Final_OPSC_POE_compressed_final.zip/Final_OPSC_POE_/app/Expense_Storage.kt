package com.example.opsc_p2_ameer_miller_st10067171

data class Expense(
    val name: String,
    val amount: Double
)